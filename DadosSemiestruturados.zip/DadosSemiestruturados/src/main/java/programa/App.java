package programa;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import conversor.ConversorXMLRegistroDeAlunos;
import model.RegistroDeAlunos;

public class App {
	
	private static List<RegistroDeAlunos> registros= new ArrayList<RegistroDeAlunos>();
	private static File file = new File("relacao_de_alunos_ufvjm.csv");
	
	private static ConversorXMLRegistroDeAlunos conversor;
	
	public static void main(String[] args) {
		lerArquivoCSV();
		
		conversor = new ConversorXMLRegistroDeAlunos();
		conversor.converter(registros);
	}
  	
	private static void lerArquivoCSV() {
		String linha = null;
		String[] valores = null;
		
		try {
			Scanner leitor = new Scanner(file);
			leitor.nextLine();
			
			while(leitor.hasNext()) {
				linha = leitor.nextLine();
				valores = linha.split(";");
				
				RegistroDeAlunos registro = new RegistroDeAlunos(valores[0],valores[1],valores[2],valores[3],valores[4],Long.parseLong(valores[5]),valores[6],valores[7]);
				registros.add(registro);
			}
			
			leitor.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
