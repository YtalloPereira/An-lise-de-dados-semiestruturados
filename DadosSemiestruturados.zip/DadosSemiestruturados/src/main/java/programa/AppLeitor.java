package programa;

import java.util.Scanner;
import leitor.LeitorXML;

public class AppLeitor {
	public static void main(String[] args) {
		
		LeitorXML leitor = new LeitorXML();
		Scanner scanner = new Scanner(System.in);
		
		while(true) {
			System.out.println("\n1 - Listar todos \n2 - Listar por estado \n3 - Listar por ano de ingresso\n4 - Porcentagem por estado\n"
					+ "5 - Listar por primeiro nome\n6 - Listar Quantidade De Alunos Por UF\n7 - Listar por Curso");
			String opcao = scanner.nextLine();
			
			if(opcao.equals("1")) {
				leitor.listarTodos();
			}else if(opcao.equals("2")) {
				System.out.println("Insira a UF do estado: ");
				String UF = scanner.nextLine();
				leitor.listarPorEstado(UF);
			}else if(opcao.equals("3")) {
				System.out.println("Insira o ano de ingresso: ");
				String ano = scanner.nextLine();
				leitor.listarPorAnoDeIngresso(ano);
				
			}else if(opcao.equals("4")){
				System.out.println("Digite o Estado: ");
				String uf = scanner.nextLine();
				leitor.porcentagemPorEstado(uf);
			}else if(opcao.equals("5")){
				System.out.println("Digite o nome: ");
				String nome = scanner.nextLine();
				leitor.listarPorNome(nome);
			}else if(opcao.equals("6")){
				System.out.println("Digite a UF do Estado: ");
				String UF = scanner.nextLine();
				leitor.qtdAlunosPorUF(UF);
			}else if(opcao.equals("7")){
				System.out.println("Digite o Curso: ");
				String curso = scanner.nextLine();
				leitor.listarPorCurso(curso);
			}else if(opcao.equals("s")) {
				break;
			}
		}
		scanner.close();
	}
}
