package leitor;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import model.RegistroDeAlunos;

public class LeitorXML {
	
	private static List<RegistroDeAlunos> registros;
	
	public LeitorXML() {
		lerXML();
	}
	
	@SuppressWarnings("unchecked")
	private static void lerXML() {
		FileReader reader = null;
		
		try {
			reader = new FileReader("Relacao_de_Alunos_ufvjm.xml");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		XStream xstream = new XStream(new DomDriver());
		registros = (List<RegistroDeAlunos>) xstream.fromXML(reader);
	}
	
	public void listarTodos() {
		for(RegistroDeAlunos alunos : registros) {
			System.out.println(alunos.toString());
			System.out.println();
		}
	}
	
	public void listarPorEstado(String estado) {
		for(RegistroDeAlunos alunos : registros) {
			if(alunos.getEstadoOrigem().equals(estado.toUpperCase())) {
				System.out.println(alunos.toString());
				System.out.println();
			}
		}
	}
	
	public void listarPorAnoDeIngresso(String anoDeIngresso) {
		String[] ano = null;
		for (RegistroDeAlunos alunos : registros) {
			ano = alunos.getAnoIngresso().split("/");
			if(ano[0].equals(anoDeIngresso)) {
				System.out.println(alunos.toString());
				System.out.println();
			}
		}
	}
	public void porcentagemPorEstado(String UF)  {
		double qtd = 0;
		for (RegistroDeAlunos registroDeAlunos : registros) {
			if(registroDeAlunos.getEstadoOrigem().equals(UF.toUpperCase())) {
				qtd++;
			}
		}
		double porcentagem;
		Double registrosTotal = (double) registros.size();
		porcentagem = (qtd * 100.0 ) / registrosTotal;
		System.out.printf("Porcentagem de Matriculados do Estado [%s] =  %.2f%s %n",UF.toUpperCase(),porcentagem,"%");
		
	}
	public void porcentagemTodosEstados() {
		List<String> ufs = new ArrayList<>();
		for (RegistroDeAlunos registroDeAlunos : registros) {
			if (ufs.contains(registroDeAlunos.getEstadoOrigem())) {
				
			}else {
				ufs.add(registroDeAlunos.getEstadoOrigem());
			}
			
		}for (String estado : ufs) {
			porcentagemPorEstado(estado);
		}
	}

	public void listarPorNome(String name) {
		String[] nome = null;
		for (RegistroDeAlunos registroDeAlunos : registros) {
			nome = registroDeAlunos.getNomeDiscente().split(" ");
			if (nome[0].equalsIgnoreCase(name)) {
				System.out.println(registroDeAlunos.getNomeDiscente());
			}
		}if(nome.equals(null)) 
			System.out.println("Nenhum Nome Encontrado!");	
	}
	public void qtdAlunosPorUF(String uf) {
		int qtd = 0;
		for (RegistroDeAlunos registroDeAlunos : registros) {
			if(registroDeAlunos.getEstadoOrigem().equals(uf.toUpperCase()))
			qtd++;
		}
		System.out.println("Existem "+qtd+" Alunos Do Estado(UF): "+uf.toUpperCase());
	}
	public void listarPorCurso(String curso) {
		boolean encontrou = false;
		for (RegistroDeAlunos registroDeAlunos : registros) {
			if(registroDeAlunos.getCurso().equals(curso.toUpperCase())){
				encontrou = true;
				System.out.println(registroDeAlunos.toString()+"\n");
				
			}
			
		}if(!encontrou) {
				System.out.println("Curso não encontrado!");
			}
	}
	public void porcentagemPorCursos(String curso) {
		double qtd = 0;
		for (RegistroDeAlunos registroDeAlunos : registros) {
			if(registroDeAlunos.getCurso().equals(curso.toUpperCase())) {
				qtd++;
			}
		}
		double porcentagem;
		Double registrosTotal = (double) registros.size();
		porcentagem = (qtd * 100.0 ) / registrosTotal;
		
		System.out.printf("Porcentagem de Matriculados no Curso [%s] =  %.2f%s %n",curso.toUpperCase(),porcentagem,"%");
		
	}
	public void porcentagemTodosOsCursos() {
		List<String> cursos = new ArrayList<>();
		for (RegistroDeAlunos registroDeAlunos : registros) {
			if (cursos.contains(registroDeAlunos.getCurso())) {
				
			}else {
				cursos.add(registroDeAlunos.getCurso());
			}
			
		}for (String curso : cursos) {
			porcentagemPorCursos(curso);
		}
	}
}
