package conversor;

import java.io.File;
import java.io.PrintWriter;
import java.util.List;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import model.RegistroDeAlunos;

public class ConversorXMLRegistroDeAlunos {
	
	public void converter(List<RegistroDeAlunos>registros) {
		XStream xstream = new XStream(new DomDriver("UTF-8"));
		
		File arquivoRegistros = new File("Relacao_de_Alunos_ufvjm.xml");
		
		String xmlRegistros = xstream.toXML(registros);
		xstream.alias("ArrayList", java.util.ArrayList.class);
		
		try {
			arquivoRegistros.createNewFile();
			PrintWriter gravador = new PrintWriter(arquivoRegistros);
			gravador.print(xmlRegistros);
			gravador.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
